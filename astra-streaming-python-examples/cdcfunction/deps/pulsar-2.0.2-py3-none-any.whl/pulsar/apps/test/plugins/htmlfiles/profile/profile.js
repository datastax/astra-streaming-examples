(function($) {
	
	$(document).ready(function() {
		$("table.tablesorter").tablesorter();
    });
	
}(jQuery));